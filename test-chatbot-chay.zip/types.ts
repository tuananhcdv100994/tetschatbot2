
export enum Role {
  USER = 'user',
  MODEL = 'model'
}

export interface MessagePart {
    text: string;
}

export interface Message {
  id: string;
  role: Role;
  parts: MessagePart[];
}

export interface CustomerInfo {
  name: string;
  phone: string;
}

export interface GroundingSource {
    uri: string;
    title: string;
}
